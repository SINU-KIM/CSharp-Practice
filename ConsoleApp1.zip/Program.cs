﻿using System;

namespace ConsoleApp1
{
    public interface Human
    {
        //Talk
        //Buy
        //Sell
    }

    public interface NotHuman
    {
        //Hostile
    }

    public class Unit
    {
        //Move                                                                                                              ?????이렇게 하면 되는건가?????
        //Attack
        //Jump
        //Hp
        //Death
    }

    public class Player : Unit, Human
    {
        //Player Skill
    }

    public class Monster : Unit, NotHuman
    {
        //Monster Skill
    }

    public class NPC : Unit, Human
    {
        //Quest
    }

    class Program
    {       
        
    }
}
